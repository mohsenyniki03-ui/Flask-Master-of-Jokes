# master_of_jokes/admin.py
from flask import Blueprint, render_template, request, redirect, url_for, flash, g
from master_of_jokes.db import get_db
from master_of_jokes.auth import login_required

bp = Blueprint('admin', __name__, url_prefix='/admin')


def moderator_required(view):
    from functools import wraps
    @wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None or g.user['role'] != 'Moderator':
            flash("Moderator access only.")
            return redirect(url_for('index'))
        return view(**kwargs)
    return wrapped_view


@bp.route('/')
@login_required
@moderator_required
def dashboard():
    db = get_db()
    users = db.execute("SELECT id, nickname, role FROM user").fetchall()
    return render_template('admin/dashboard.html', users=users)

@bp.route('/promote', methods=['POST'])
@login_required
@moderator_required
def promote():
    user_id = request.form['user_id']
    db = get_db()
    db.execute("UPDATE user SET role = 'Moderator' WHERE id = ?", (user_id,))
    db.commit()
    flash("User promoted to Moderator.")
    return redirect(url_for('admin.dashboard'))


@bp.route('/demote', methods=['POST'])
@login_required
@moderator_required
def demote():
    user_id = request.form['user_id']
    db = get_db()
    # Ensure we are not removing the last moderator
    count = db.execute("SELECT COUNT(*) FROM user WHERE role = 'Moderator'").fetchone()[0]
    if count > 1:
        db.execute("UPDATE user SET role = 'User' WHERE id = ?", (user_id,))
        db.commit()
        flash("Moderator demoted to User.")
    else:
        flash("You can't remove the last moderator.")
    return redirect(url_for('admin.dashboard'))

@bp.route('/update-balance', methods=['POST'])
@login_required
@moderator_required
def update_balance():
    db = get_db()
    db.execute("UPDATE user SET joke_balance = ? WHERE id = ?", (request.form['new_balance'], request.form['user_id']))
    db.commit()
    flash("Balance updated.")
    return redirect(url_for('admin.dashboard'))

