import functools
import re

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash
import hashlib

from master_of_jokes.db import get_db

bp = Blueprint('auth', __name__, url_prefix='/auth')


def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))

        return view(**kwargs)

    return wrapped_view


@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')

    if user_id is None:
        g.user = None
    else:
        g.user = get_db().execute(
            'SELECT * FROM user WHERE id = ?', (user_id,)
        ).fetchone()



@bp.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        email = request.form['email']
        nickname = request.form['nickname']
        password = request.form['password']
        db = get_db()
        error = None

        if not email:
            error = 'Email is required.'
        elif not nickname:
            error = 'Nickname is required.'
        elif not password:
            error = 'Password is required.'
        elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            error = 'Invalid email format.'
        elif db.execute(
            'SELECT id FROM user WHERE email = ?', (email,)
        ).fetchone() is not None:
            error = f"Email {email} is already registered."
        elif db.execute(
            'SELECT id FROM user WHERE nickname = ?', (nickname,)
        ).fetchone() is not None:
            error = f"Nickname {nickname} is already taken."

        if error is None:
            # Create a custom password hash instead of using Werkzeug's default
            # which might use scrypt on some systems
            password_hash = 'pbkdf2:sha256:' + hashlib.pbkdf2_hmac(
                'sha256', 
                password.encode('utf-8'), 
                hashlib.sha256(email.encode('utf-8')).digest(), 
                100000
            ).hex()
            
            db.execute(
                'INSERT INTO user (email, nickname, password) VALUES (?, ?, ?)',
                (email, nickname, password_hash)
            )
            db.commit()
            return redirect(url_for('auth.login'))

        flash(error)

    return render_template('auth/register.html')


@bp.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None

        # Allow login with either email or nickname
        user = db.execute(
            'SELECT * FROM user WHERE email = ? OR nickname = ?',
            (username, username)
        ).fetchone()

        if user is None:
            error = 'Incorrect username or password.'
        else:
            # For users registered with the custom password hash
            if user['password'].startswith('pbkdf2:sha256:'):
                # Extract the hash part
                stored_hash = user['password'].split(':', 2)[2]
                # Compute the hash of the provided password
                computed_hash = hashlib.pbkdf2_hmac(
                    'sha256', 
                    password.encode('utf-8'), 
                    hashlib.sha256(user['email'].encode('utf-8')).digest(), 
                    100000
                ).hex()
                
                if stored_hash != computed_hash:
                    error = 'Incorrect username or password.'
            else:
                # Fallback to werkzeug's check_password_hash for compatibility
                if not check_password_hash(user['password'], password):
                    error = 'Incorrect username or password.'

        if error is None:
            session.clear()
            session['user_id'] = user['id']
            session['user_role'] = user['role']
            return redirect(url_for('jokes.create'))

        flash(error)

    return render_template('auth/login.html')


@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))